# 📖 GUIDE : Créer ton repo GitHub "mes-cours-lycee"

## ✅ Étapes à suivre

### **ÉTAPE 1 : Créer un compte GitHub (si tu n'en as pas)**

1. Va sur **https://github.com**
2. Clique sur **"Sign up"** (en haut à droite)
3. Entre :
   - Email : (ton email)
   - Password : (mot de passe fort)
   - Username : (ton pseudo GitHub, ex: `karim-biotech`)
4. Valide et suis les instructions d'email

✅ **Compte créé !**

---

### **ÉTAPE 2 : Créer un nouveau repository**

1. Une fois connecté, clique sur **"+"** (en haut à droite)
2. Sélectionne **"New repository"**
3. Remplis les champs :
   - **Repository name** : `mes-cours-lycee`
   - **Description** : (optionnel) `Ressources pédagogiques STL, ST2S, BTS`
   - **Public** : ✅ Coche cette case (visible pour tous)
   - **Add a README file** : ✅ Coche cette case
4. Clique sur **"Create repository"**

✅ **Repo créé !**

---

### **ÉTAPE 3 : Uploader les fichiers**

#### **Option A : Via l'interface GitHub (simple)**

1. Dans ton repo, clique sur **"Add file"** → **"Upload files"**
2. Drag-and-drop les fichiers (ou clique pour parcourir)
3. Sélectionne tous les fichiers de la structure :
   ```
   README.md
   .gitignore
   1STL/ (dossier complet)
   TSTL/ (dossier complet)
   1ST2S/ (dossier complet)
   TST2S/ (dossier complet)
   BTS1/ (dossier complet)
   BTS2/ (dossier complet)
   _Documentation/ (dossier)
   Ressources-Externes/ (dossier)
   ```
4. Clique sur **"Commit changes"**

✅ **Fichiers uploadés !**

#### **Option B : Via Git (plus avancé)**

Si tu maîtrises Git :
```bash
git clone https://github.com/[TON_USERNAME]/mes-cours-lycee.git
cd mes-cours-lycee
# Copie tous les fichiers de la structure ici
git add .
git commit -m "📚 Structure initiale du repo pédagogique"
git push origin main
```

---

### **ÉTAPE 4 : Activer GitHub Pages (site web)**

1. Va dans les **Settings** du repo (onglet en haut)
2. Scroll vers le bas → **"Pages"**
3. Sous **"Source"**, sélectionne :
   - Branch : `main`
   - Folder : `/ (root)`
4. Clique sur **"Save"**
5. GitHub génère une URL : `https://[USERNAME].github.io/mes-cours-lycee/`

✅ **Site web activé !**

---

### **ÉTAPE 5 : Organiser ton contenu**

Maintenant, ajoute tes ressources en respectant le nommage :

**Format :** `[NIVEAU]_[MATIÈRE]_[TYPE]_[SUJET].ext`

**Exemples :**
- `TSTL_Biochimie_Cours_Metabolisme.pdf` → `/TSTL/Cours/`
- `TSTL_Biochimie_TD_Metabolisme.pdf` → `/TSTL/TD/`
- `1STL_Microbiologie_TP_CultureBacterienne.pdf` → `/1STL/TP-AE/`
- `TST2S_BiologieHumaine_Annales_2024.pdf` → `/TST2S/Annales/`

---

## 🎯 Résumé des dossiers

```
mes-cours-lycee/
├── README.md (accueil du site)
├── .gitignore
├── 1STL/
│   ├── Cours/
│   ├── TD/
│   ├── TP-AE/
│   └── Annales/
├── TSTL/
│   ├── Cours/
│   ├── TD/
│   ├── TP-AE/
│   └── Annales/
├── 1ST2S/
│   ├── Cours/
│   ├── TD/
│   ├── TP-AE/
│   └── Annales/
├── TST2S/
│   ├── Cours/
│   ├── TD/
│   ├── TP-AE/
│   └── Annales/
├── BTS1/
│   ├── Cours/
│   ├── TD/
│   ├── TP-AE/
│   └── Annales/
├── BTS2/
│   ├── Cours/
│   ├── TD/
│   ├── TP-AE/
│   └── Annales/
├── _Documentation/ (guides pédagogiques)
└── Ressources-Externes/ (liens externes)
```

---

## 🚀 Une fois en ligne

**Ton site sera accessible à :**
```
https://[USERNAME].github.io/mes-cours-lycee/
```

**Tes élèves peuvent :**
- 📖 Lire les cours directement
- 📥 Télécharger les PDF
- 🔍 Chercher par niveau/matière
- 📱 Accéder depuis n'importe quel appareil

---

## 💡 Conseils

✅ **Mets à jour régulièrement** tes ressources
✅ **Respecte le nommage** pour que tout soit bien classé
✅ **Teste le site** avec d'autres appareils (mobile, tablette)
✅ **Partage le lien** avec tes élèves et collègues

---

## 🆘 Aide supplémentaire

- Documentation GitHub : https://docs.github.com/
- GitHub Pages guide : https://docs.github.com/en/pages
- Markdown syntax : https://guides.github.com/features/mastering-markdown/

---

**Bon courage pour la création ! 🎉**
