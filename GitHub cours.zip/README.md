# 📚 Ressources Pédagogiques — Biotechnologies & Biologie Humaine

**Bienvenue !** Ce site centralise l'ensemble des ressources pédagogiques en biotechnologies, biochimie et biologie humaine pour les niveaux du lycée technologique et BTS.

---

## 🎓 **Structure des ressources**

Les ressources sont organisées par **niveau de classe** et **filière** :

### **Lycée Technologique**

#### **1ère Technologique STL** (`1STL`)
Spécialités : Biochimie-Biologie, Biotechnologies
- [Cours](./1STL/Cours/)
- [Travaux Dirigés (TD)](./1STL/TD/)
- [Travaux Pratiques / Activités Expérimentales (TP-AE)](./1STL/TP-AE/)
- [Annales d'examens](./1STL/Annales/)

#### **Terminale STL** (`TSTL`)
Spécialités : Biochimie-Biologie, Biotechnologies
- [Cours](./TSTL/Cours/)
- [Travaux Dirigés (TD)](./TSTL/TD/)
- [Travaux Pratiques / Activités Expérimentales (TP-AE)](./TSTL/TP-AE/)
- [Annales d'examens](./TSTL/Annales/)

#### **1ère Technologique ST2S** (`1ST2S`)
Spécialité : Biologie et Physiopathologie Humaines
- [Cours](./1ST2S/Cours/)
- [Travaux Dirigés (TD)](./1ST2S/TD/)
- [Travaux Pratiques / Activités Expérimentales (TP-AE)](./1ST2S/TP-AE/)
- [Annales d'examens](./1ST2S/Annales/)

#### **Terminale ST2S** (`TST2S`)
Spécialité : Biologie et Physiopathologie Humaines
- [Cours](./TST2S/Cours/)
- [Travaux Dirigés (TD)](./TST2S/TD/)
- [Travaux Pratiques / Activités Expérimentales (TP-AE)](./TST2S/TP-AE/)
- [Annales d'examens](./TST2S/Annales/)

### **Enseignement Supérieur**

#### **BTS Bioanalyses et Contrôles de Laboratoire (BioAlc)**

**1ère année** (`BTS1`)
- [Cours](./BTS1/Cours/)
- [Travaux Dirigés (TD)](./BTS1/TD/)
- [Travaux Pratiques / Activités Expérimentales (TP-AE)](./BTS1/TP-AE/)
- [Annales d'examens](./BTS1/Annales/)

**2ème année** (`BTS2`)
- [Cours](./BTS2/Cours/)
- [Travaux Dirigés (TD)](./BTS2/TD/)
- [Travaux Pratiques / Activités Expérimentales (TP-AE)](./BTS2/TP-AE/)
- [Annales d'examens](./BTS2/Annales/)

---

## 📋 **Convention de nommage des fichiers**

Tous les fichiers suivent la convention suivante pour faciliter le classement :

```
[NIVEAU]_[MATIÈRE]_[TYPE]_[SUJET].ext
```

**Exemple :**
- `TSTL_Biochimie_Cours_Metabolisme.pdf`
- `1STL_Microbiologie_TD_CultureBacterienne.pdf`
- `TST2S_BiologieHumaine_TP_SystemeCardiovasculaire.pdf`
- `BTS1_ChimieAnalytique_Cours_Chromatographie.pdf`

**Niveaux autorisés :** `1STL`, `TSTL`, `1ST2S`, `TST2S`, `BTS1`, `BTS2`

**Matières :** Biochimie, Microbiologie, Biotechnologie, BiologieHumaine, Immunologie, ChimieAnalytique, Autres

**Types :** Cours, TD, TP, AE, Annales, Evaluation

---

## 🔍 **Comment naviguer**

### Pour les **élèves** :
1. Trouvez votre **niveau** (ex: TSTL)
2. Consultez les **cours** pour comprendre les concepts
3. Travaillez les **TD** pour l'application
4. Préparez les **TP** pour les manipulations pratiques
5. Entraînez-vous avec les **annales** pour le bac

### Pour les **enseignants** :
1. Consultez les ressources existantes
2. Adaptez-les à votre pédagogie
3. Proposez des améliorations (fork + pull request)
4. Partagez vos ressources avec la communauté

---

## 📚 **Matières couvertes**

- **Biochimie** : Métabolisme, Enzymatique, Bioénergétique
- **Microbiologie** : Bactériologie, Virologie, Mycologie, Fermentation
- **Biotechnologie** : Génie génétique, Cultures cellulaires, Bioréacteurs
- **Biologie Humaine** : Anatomie, Physiologie, Pathologie
- **Immunologie** : Système immunitaire, Sérologie, Vaccination
- **Chimie Analytique** : Dosages, Chromatographie, Électrophorèse

---

## 🎯 **Programmes de référence**

- **STL** : BO spécial n°1 (22 janvier 2019) — 1STL & BO spécial n°8 (25 juillet 2019) — TSTL
- **ST2S** : BO spécial n°1 (22 janvier 2019) — 1ST2S & BO spécial n°8 (25 juillet 2019) — TST2S
- **BTS BioAlc** : Arrêté du 6 mars 2023 — JO du 12 mars 2023

---

## 🔗 **Ressources externes recommandées**

- 🎓 [Éduscol — Biotechnologies](https://eduscol.education.fr/2340/biotechnologies-sciences-et-techniques-medico-sociales)
- 📺 [Ressources Lumni](https://www.lumni.fr/)
- 📖 [Edubase — Fiches pédagogiques](https://www.edubase.fr/)
- 🧬 [3RB — Réseau Ressources Risques Biologiques](https://www.ac-paris.fr/3rb/)
- 📋 [Annales TSTL Versailles](https://genie-bio.ac-versailles.fr/spip.php?article178)
- 📋 [Annales TSTL Bordeaux](https://ent2d.ac-bordeaux.fr/disciplines/biotechnologies-sante-social/pedagogie/annales-du-bac-stl-biotechnologies/)
- 📋 [Annales TSTL Versailles (complémentaires)](https://genie-bio.ac-versailles.fr/spip.php?article457)
- 📋 [Annales TST2S Versailles](https://genie-bio.ac-versailles.fr/spip.php?article255)
- 📋 [Annales TST2S Créteil](https://biotechnologies.ac-creteil.fr/spip.php?page=rubrique&id_rubrique=54)

---

## 📝 **Version et maintenance**

- **Dernière mise à jour** : Mars 2026
- **Auteur** : Karim (Enseignant STL-ST2S-BTS)
- **Licence** : Creative Commons — Attribution — Pas d'Utilisation Commerciale

---

## 📧 **Contact & Contribution**

Pour toute question, amélioration ou contribution :
- Créez une **Issue** sur ce repo
- Proposez une **Pull Request** avec vos améliorations
- Contactez l'enseignant directement

---

**Bon travail à tous ! 🚀**
