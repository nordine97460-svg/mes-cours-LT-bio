# 📦 PROJET : Site GitHub pour Cours

**Nom du projet :** `site Github pour cours`
**Repo GitHub :** `mes-cours-lycee`
**Créé :** Mars 2026
**Auteur :** Claude (pour Karim — Enseignant STL/ST2S/BTS)

---

## ✅ Ce qui a été créé

### 1. **Structure complète du repository**

Dossiers organisés pour **6 niveaux** :
- ✅ `1STL/` (1ère Technologique STL)
- ✅ `TSTL/` (Terminale STL)
- ✅ `1ST2S/` (1ère Technologique ST2S)
- ✅ `TST2S/` (Terminale ST2S)
- ✅ `BTS1/` (BTS BioAlc — 1ère année)
- ✅ `BTS2/` (BTS BioAlc — 2ème année)

Chaque niveau contient **4 sous-dossiers** :
- `Cours/` — Cours magistraux
- `TD/` — Travaux Dirigés
- `TP-AE/` — Travaux Pratiques / Activités Expérimentales
- `Annales/` — Annales d'examens

Plus :
- ✅ `_Documentation/` — Guides pédagogiques
- ✅ `Ressources-Externes/` — Liens externes

### 2. **Fichiers de base**

- ✅ **README.md** (5.3 KB) — Accueil et navigation du site
- ✅ **.gitignore** — Fichiers à ignorer sur GitHub
- ✅ **GUIDE_GITHUB.md** — Instructions étape par étape

### 3. **Contenu initial**

Ressources prêtes à uploader :
- ✅ **Cours_Metabolisme_TSTL.docx** (15 KB) — Cours complet métabolisme TSTL
- ✅ **TD_Metabolisme_2h_TSTL.docx** (14 KB) — TD 2h avec corrigés

### 4. **Convention de nommage**

Format standardisé pour tous les fichiers :
```
[NIVEAU]_[MATIÈRE]_[TYPE]_[SUJET].ext
```

**Exemple :**
- `TSTL_Biochimie_Cours_Metabolisme.pdf`
- `1STL_Microbiologie_TD_CultureBacterienne.pdf`
- `TST2S_BiologieHumaine_TP_SystemeCardiovasculaire.pdf`
- `BTS1_ChimieAnalytique_Cours_Chromatographie.pdf`

---

## 🎯 Prochaines étapes pour Karim

### **1. Créer un compte GitHub** (5 min)
→ https://github.com/signup

### **2. Créer le repo "mes-cours-lycee"** (3 min)
→ Voir `GUIDE_GITHUB.md`

### **3. Uploader les fichiers de la structure** (10 min)
→ Utiliser l'interface GitHub ou Git CLI

### **4. Ajouter tes ressources pédagogiques** (progressif)
→ Renommer tes fichiers selon le format
→ Uploader dans les bons dossiers

### **5. Activer GitHub Pages** (2 min)
→ Site web automatiquement généré
→ Accessible à `https://[USERNAME].github.io/mes-cours-lycee/`

---

## 📚 Ressources pédagogiques à ajouter

**À renommer et uploader selon le format :**

**1STL :**
- [ ] Cours biochimie
- [ ] Cours microbiologie
- [ ] Cours biotechnologie
- [ ] TD + TP

**TSTL :**
- [x] Cours métabolisme (✅ déjà généré)
- [x] TD métabolisme (✅ déjà généré)
- [ ] Cours autres sujets
- [ ] TD/TP autres sujets
- [ ] Annales

**1ST2S :**
- [ ] Cours biologie humaine
- [ ] TD
- [ ] TP/AE

**TST2S :**
- [ ] Cours biologie humaine
- [ ] TD
- [ ] TP/AE
- [ ] Annales

**BTS1 :**
- [ ] Cours (Microbiologie, Chimie analytique, Biotechnologie)
- [ ] TD
- [ ] TP/AE

**BTS2 :**
- [ ] Cours
- [ ] TD
- [ ] TP/AE
- [ ] Annales

---

## 🔗 Ressources officielles intégrées

Le README.md inclut des liens vers :
- 🎓 Éduscol
- 📺 Lumni
- 📖 Edubase
- 🧬 3RB
- 📋 Annales STL (Versailles, Bordeaux)
- 📋 Annales ST2S (Versailles, Créteil)

---

## 💾 Fichiers à télécharger/copier

**Dans `/mnt/user-data/outputs/` :**

```
README.md
.gitignore
GUIDE_GITHUB.md
Cours_Metabolisme_TSTL.docx
TD_Metabolisme_2h_TSTL.docx

1STL/
├── Cours/
│   └── INDEX.md
├── TD/
│   └── INDEX.md
├── TP-AE/
│   └── INDEX.md
└── Annales/
    └── INDEX.md

TSTL/
├── Cours/
│   └── INDEX.md
├── TD/
│   └── INDEX.md
├── TP-AE/
│   └── INDEX.md
└── Annales/
    └── INDEX.md

[... idem pour 1ST2S, TST2S, BTS1, BTS2 ...]

_Documentation/
Ressources-Externes/
```

---

## 🚀 Avantages de cette approche

✅ **Gratuit** — Zéro coût d'hébergement
✅ **Simple** — Interface GitHub intuitive
✅ **Maintenable** — Modification facile des fichiers
✅ **Scalable** — Ajoute des ressources quand tu veux
✅ **Partageable** — Lien simple pour élèves/collègues
✅ **Durable** — GitHub existe depuis +15 ans
✅ **Web search friendly** — Consultable par Claude (économie tokens)
✅ **Mobile-friendly** — Accessible sur tous les appareils

---

## 📝 Notes importantes

- **Convention de nommage** : Respecte `[NIVEAU]_[MATIÈRE]_[TYPE]_[SUJET].ext`
- **Formats acceptés** : PDF, DOCX, TXT, Markdown, images, vidéos
- **GitHub Pages** : Site web généré automatiquement
- **Versionning** : Historique de tous les changements conservé
- **Accès** : Public (tout le monde peut voir, pas de modification)

---

## 🎓 Pour l'avenir

**Possibilités d'améliorations :**
- Ajouter des schémas/images dans les dossiers
- Créer des fichiers Markdown pour mieux afficher le contenu
- Intégrer un système de TOC (Table des matières)
- Ajouter des badges de progression
- Créer des wikis pour chaque sujet

---

## 💬 Besoin d'aide ?

Contact Claude pour :
- ✅ Générer des cours/TD/TP supplémentaires
- ✅ Créer de nouvelles compétences (TP microbiologie, etc.)
- ✅ Modifier le README ou la structure
- ✅ Convertir DOCX → Markdown pour GitHub Pages
- ✅ Questions sur Git/GitHub

---

**Projet créé et enregistré sous : "site Github pour cours"** 🎉
